
let boxes = document.querySelectorAll(".box");

boxes.forEach(function(box) {
    box.addEventListener("click", function() {
        box.style.backgroundColor = box.textContent;
    });
});

let input = document.querySelector("#username");
let button = document.querySelector("#submit");
let name = document.querySelector("#name");

button.addEventListener("click", function() {
    name.textContent = input.value;
});
